CREATE TYPE type_collectivite AS ENUM (
    'COMMUNE',
    'COMMUNAUTE_URBAINE',
    'COMMUNAUTE_DE_COMMUNES',
    'REGION'
);

CREATE TYPE statut_collectivite AS ENUM (
    'ACTIVE',
    'SUSPENDUE',
    'ARCHIVEE'
);

CREATE TYPE role_application AS ENUM (
    'SUPER_ADMINISTRATEUR',
    'ADMINISTRATEUR',
    'CONTROLEUR_FINANCIER',
    'ORDONNATEUR',
    'REGISSEUR',
    'COSIGNATAIRE',
    'CHEF_SERVICE',
    'RECEVEUR'
);

CREATE TYPE statut_utilisateur AS ENUM (
    'ACTIF',
    'SUSPENDU',
    'DESACTIVE'
);

CREATE TYPE type_exercice AS ENUM (
    'NORMAL',
    'PROLONGATION'
);

CREATE TYPE statut_budget AS ENUM (
    'BROUILLON',
    'SOUMIS',
    'APPROUVE',
    'MODIFIE',
    'CLOTURE'
);

CREATE TYPE type_budget AS ENUM (
    'PRIMITIF',
    'ADDITIONNEL',
    'DECISION_MODIFICATIVE'
);

CREATE TYPE type_engagement AS ENUM (
    'BON_COMMANDE',
    'LETTRE_COMMANDE',
    'MARCHE',
    'PROVISIONNEL',
    'AUTRE',
    'REGULARISATION_470XX'
);

CREATE TYPE statut_engagement AS ENUM (
    'BROUILLON',
    'SOUMIS_CF',
    'VISA',
    'VISA_OBSERVATIONS',
    'VISA_RESERVES',
    'REJETE',
    'CONFIRME',
    'ANNULE',
    'CLOTURE'
);

CREATE TYPE type_avis_controle AS ENUM (
    'VISA',
    'VISA_AVEC_OBSERVATIONS',
    'VISA_AVEC_RESERVES',
    'REJET'
);

CREATE TYPE type_facture AS ENUM (
    'COMPLETE',
    'PARTIELLE',
    'PRO_FORMA',
    'AVOIR',
    'RECTIFICATIVE',
    'REGULARISATION'
);

CREATE TYPE statut_liquidation AS ENUM (
    'BROUILLON',
    'SOUMISE',
    'VALIDEE',
    'REJETEE',
    'ANNULEE'
);

CREATE TYPE type_mandat AS ENUM (
    'INDIVIDUEL',
    'COLLECTIF',
    'REGULARISATION_REGIE',
    'RETENUE_GARANTIE',
    'REGLEMENT_OFFICE'
);

CREATE TYPE statut_mandat AS ENUM (
    'BROUILLON',
    'SOUMIS_CF',
    'DEPENSE_VALIDEE',
    'REJETE',
    'TRANSMIS_RECEVEUR',
    'PRIS_EN_CHARGE',
    'PAYE',
    'ANNULE'
);

CREATE TYPE mode_reglement AS ENUM (
    'CAISSE',
    'CHEQUE',
    'VIREMENT',
    'VIREMENT_GROUPE'
);

CREATE TYPE statut_paiement AS ENUM (
    'PROGRAMME',
    'EN_ATTENTE',
    'EXECUTE',
    'DIFFERE',
    'REJETE',
    'ANNULE'
);

CREATE TYPE type_regie AS ENUM (
    'AVANCES',
    'RECETTES'
);

CREATE TYPE statut_regie AS ENUM (
    'ACTIVE',
    'SUSPENDUE',
    'CLOTUREE'
);

CREATE TYPE type_contenu AS ENUM (
    'TEXTE',
    'HTML',
    'MARKDOWN',
    'JSON'
);

CREATE TYPE niveau_notification AS ENUM (
    'INFO',
    'AVERTISSEMENT',
    'ERREUR',
    'CRITIQUE'
);

CREATE TYPE EtatRegularisation AS ENUM (
    'DETECTEE',
    'NOTIFIEE',
    'ENGAGEMENT_CREE',
    'SOUMIS_CF',
    'VISE_CF',
    'REJET_CF',
    'LIQUIDEE',
    'MANDATEE',
    'CONTREPASSEE',
    'REGULIERISEE',
    'DEPASSEMENT_DELAI'
);
