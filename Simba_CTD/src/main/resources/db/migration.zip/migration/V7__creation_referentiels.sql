CREATE TABLE lignes_budgetaires (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    exercice_id UUID NOT NULL,

    budget_id UUID NOT NULL,

    code VARCHAR(100) NOT NULL,

    libelle VARCHAR(255) NOT NULL,

    section VARCHAR(100),

    chapitre VARCHAR(100),

    article VARCHAR(100),

    compte VARCHAR(100),

    credit_vote NUMERIC(19,2) NOT NULL DEFAULT 0,

    credit_modifie NUMERIC(19,2) NOT NULL DEFAULT 0,

    credit_engage NUMERIC(19,2) NOT NULL DEFAULT 0,

    credit_liquide NUMERIC(19,2) NOT NULL DEFAULT 0,

    credit_mandate NUMERIC(19,2) NOT NULL DEFAULT 0,

    credit_paye NUMERIC(19,2) NOT NULL DEFAULT 0,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (exercice_id)
        REFERENCES exercices_budgetaires(id),

    FOREIGN KEY (budget_id)
        REFERENCES budgets(id),

    UNIQUE (collectivite_id, exercice_id, code)
);

CREATE TABLE documents_preparatoires (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    reference VARCHAR(100) NOT NULL,

    type_document type_engagement NOT NULL,

    objet TEXT,

    tiers_id UUID,

    montant_ht NUMERIC(19,2),
    montant_taxes NUMERIC(19,2),
    montant_ttc NUMERIC(19,2),

    date_document DATE,

    montant_consomme NUMERIC(19,2) NOT NULL DEFAULT 0,

    montant_restant NUMERIC(19,2),

    statut VARCHAR(50),

    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (tiers_id)
        REFERENCES tiers(id)
        ON DELETE RESTRICT,

    UNIQUE (collectivite_id, reference)
);
