
--Cette table c'est pour stocker les variables_css liées au style pour rendre l'application
--le plus parametrique possible.
CREATE TABLE configurations_visuelles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL UNIQUE,

    couleur_primaire VARCHAR(20) NOT NULL DEFAULT '#2563EB',
    couleur_secondaire VARCHAR(20) NOT NULL DEFAULT '#64748B',
    couleur_accent VARCHAR(20) NOT NULL DEFAULT '#0EA5E9',

    couleur_succes VARCHAR(20) NOT NULL DEFAULT '#16A34A',
    couleur_avertissement VARCHAR(20) NOT NULL DEFAULT '#F59E0B',
    couleur_erreur VARCHAR(20) NOT NULL DEFAULT '#DC2626',
    couleur_information VARCHAR(20) NOT NULL DEFAULT '#2563EB',

    couleur_fond VARCHAR(20) NOT NULL DEFAULT '#FFFFFF',
    couleur_surface VARCHAR(20) NOT NULL DEFAULT '#F8FAFC',
    couleur_texte VARCHAR(20) NOT NULL DEFAULT '#0F172A',

    police_principale VARCHAR(100) NOT NULL DEFAULT 'Inter',
    police_secondaire VARCHAR(100) NOT NULL DEFAULT 'Inter',
    police_titres VARCHAR(100) NOT NULL DEFAULT 'Inter',

    taille_police_base VARCHAR(20) NOT NULL DEFAULT '16px',

    rayon_bordure VARCHAR(20) NOT NULL DEFAULT '0.5rem',

    mode_affichage VARCHAR(20) NOT NULL DEFAULT 'SYSTEME',

    variables_css JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_configuration_visuelle_collectivite
        FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE
);

--==== pour stocker les parametres de delai, de contraintes et de seuil..etc
CREATE TABLE parametres_reglementaires (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    code VARCHAR(100) NOT NULL,

    libelle VARCHAR(255) NOT NULL,

    valeur_numerique NUMERIC(19,6),

    valeur_texte TEXT,

    valeur_booleenne BOOLEAN,

    unite VARCHAR(50),

    description TEXT,

    date_debut DATE,

    date_fin DATE,

    actif BOOLEAN NOT NULL DEFAULT TRUE,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_parametre_collectivite
        FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    CONSTRAINT uq_parametre_collectivite_code
        UNIQUE (collectivite_id, code)
);

-- Cette table est utilisé pour rendre les menus de la sidebar dynamique en fonction du role de l'utilisateur
CREATE TABLE menus (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    code VARCHAR(100) NOT NULL,

    libelle VARCHAR(255) NOT NULL,

    icone VARCHAR(100),

    chemin VARCHAR(255),

    ordre INTEGER NOT NULL DEFAULT 0,

    --parent_id UUID,

    actif BOOLEAN NOT NULL DEFAULT TRUE,

    roles_autorises JSONB NOT NULL DEFAULT '[]'::jsonb,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    --FOREIGN KEY (parent_id)
      --  REFERENCES menus(id)
        --ON DELETE CASCADE,

    UNIQUE (collectivite_id, code)
);


CREATE TABLE fonctionnalites_collectivites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    code VARCHAR(100) NOT NULL,

    active BOOLEAN NOT NULL DEFAULT TRUE,

    configuration JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    UNIQUE (collectivite_id, code)
);
