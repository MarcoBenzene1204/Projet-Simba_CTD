CREATE TABLE collectivites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    code VARCHAR(30) NOT NULL UNIQUE,

    nom VARCHAR(255) NOT NULL,

    type type_collectivite NOT NULL,

    region VARCHAR(150),
    departement VARCHAR(150),
    arrondissement VARCHAR(150),

    adresse TEXT,
    telephone VARCHAR(30),
    email CITEXT,

    logo_url TEXT,

    statut statut_collectivite NOT NULL DEFAULT 'ACTIVE',

    fuseau_horaire VARCHAR(80) NOT NULL DEFAULT 'Africa/Douala',

    devise VARCHAR(10) NOT NULL DEFAULT 'XAF',

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
