INSERT INTO collectivites (
    code,
    nom,
    type,
    region,
    departement,
    arrondissement,
    adresse,
    telephone,
    email
)
VALUES (
    'CTD-YDE-001',
    'Commune de Yaoundé',
    'COMMUNE',
    'Centre',
    'Mfoundi',
    'Yaoundé',
    'Yaoundé, Centre, Cameroun',
    '+237 600000000',
    'contact@communeyaounde.cm'
)
RETURNING id, code, nom;
