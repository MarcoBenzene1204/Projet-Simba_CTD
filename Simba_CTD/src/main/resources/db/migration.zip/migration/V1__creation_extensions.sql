    --L'extension pgcrypto nous permet d'utiliser gen_random_uuid() pour nos identifiants.
    -- et aussi pour pouvoir hacher le mot de passe dans postgresql
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    --l'extension si dessous permet de rendre un champs incensible à la casse
    CREATE EXTENSION IF NOT EXISTS citext;
