CREATE TABLE mandats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    exercice_id UUID NOT NULL,

    numero VARCHAR(100) NOT NULL,

    type_mandat type_mandat NOT NULL,

    montant_total NUMERIC(19,2) NOT NULL DEFAULT 0,

    statut statut_mandat NOT NULL DEFAULT 'BROUILLON',

    date_mandatement DATE NOT NULL,

    ordonnateur_id UUID NOT NULL,

    controleur_id UUID,

    receveur_id UUID,

    bordereau_numero VARCHAR(100),

    depense_validee_at TIMESTAMPTZ,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (exercice_id)
        REFERENCES exercices_budgetaires(id),

    FOREIGN KEY (ordonnateur_id)
        REFERENCES utilisateurs(id),

    FOREIGN KEY (controleur_id)
        REFERENCES utilisateurs(id),

    FOREIGN KEY (receveur_id)
        REFERENCES utilisateurs(id),

    UNIQUE (collectivite_id, numero)
);


CREATE TABLE mandat_liquidations (
    mandat_id UUID NOT NULL,

    liquidation_id UUID NOT NULL,

    montant NUMERIC(19,2) NOT NULL,

    PRIMARY KEY (mandat_id, liquidation_id),

    FOREIGN KEY (mandat_id)
        REFERENCES mandats(id)
        ON DELETE CASCADE,

    FOREIGN KEY (liquidation_id)
        REFERENCES liquidations(id)
        ON DELETE RESTRICT
);
