CREATE TABLE exercices_budgetaires (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    annee INTEGER NOT NULL,

    type_exercice type_exercice NOT NULL DEFAULT 'NORMAL',

    date_debut DATE NOT NULL,

    date_fin DATE NOT NULL,

    actif BOOLEAN NOT NULL DEFAULT FALSE,

    cloture BOOLEAN NOT NULL DEFAULT FALSE,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    UNIQUE (collectivite_id, annee)
);

CREATE TABLE budgets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    exercice_id UUID NOT NULL,

    type_budget type_budget NOT NULL,

    numero VARCHAR(50),

    libelle VARCHAR(255),

    montant_total NUMERIC(19,2) NOT NULL DEFAULT 0,

    statut statut_budget NOT NULL DEFAULT 'BROUILLON',

    date_approbation DATE,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (exercice_id)
        REFERENCES exercices_budgetaires(id)
        ON DELETE RESTRICT
);
