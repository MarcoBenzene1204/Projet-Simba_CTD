CREATE INDEX idx_regies_regisseur ON regies_avances(regisseur_id);
CREATE INDEX idx_regies_etat ON regies_avances(etat);

CREATE INDEX idx_engagements_ordonnator ON engagements(ordonnator_id);
CREATE INDEX idx_engagements_ligne ON engagements(lignebudgetaire_id);
CREATE INDEX idx_engagements_etat ON engagements(etat);
CREATE INDEX idx_engagements_date ON engagements(date_engagement);

CREATE INDEX idx_apurements_regie ON apurements_regies(regieavances_id);
CREATE INDEX idx_apurements_etat ON apurements_regies(etat);
CREATE INDEX idx_apurements_date_periode ON apurements_regies(date_periode);

CREATE INDEX idx_depenses_regie ON depenses_regies(regie_avances_id);
CREATE INDEX idx_depenses_etat ON depenses_regies(etat);
CREATE INDEX idx_depenses_date ON depenses_regies(date_depense);

CREATE INDEX idx_liquidations_engagement ON liquidations(engagement_id);
CREATE INDEX idx_liquidations_etat ON liquidations(etat);
CREATE INDEX idx_liquidations_num_facture ON liquidations(numero_facture);

CREATE INDEX idx_mandats_engagement ON mandats(engagement_id);
CREATE INDEX idx_mandats_ordonnator ON mandats(ordonnator_id);
CREATE INDEX idx_mandats_etat ON mandats(etat);
CREATE INDEX idx_mandats_etat_paiement ON mandats(etat_paiement);

CREATE INDEX idx_ligne_mandat_mandat ON ligne_mandat(mandat_id);
CREATE INDEX idx_ligne_mandat_liquidation ON ligne_mandat(liquidation_id);
CREATE INDEX idx_ligne_mandat_tiers ON ligne_mandat(tiers_id);

CREATE INDEX idx_paiements_receve ON paiements(receve_id);
CREATE INDEX idx_paiements_etat ON paiements(etat);
CREATE INDEX idx_paiements_date_reception ON paiements(date_reception_mandat);

CREATE INDEX idx_regularisations_etat ON regularisations_470xx(etat);
CREATE INDEX idx_regularisations_echeance ON regularisations_470xx(date_echeance_regularisation);
CREATE INDEX idx_regularisations_receve ON regularisations_470xx(receve_id);
CREATE INDEX idx_regularisations_ordonnator ON regularisations_470xx(ordonnator_id);