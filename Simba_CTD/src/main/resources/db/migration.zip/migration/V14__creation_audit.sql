CREATE TABLE journal_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID,

    utilisateur_id UUID,

    action VARCHAR(100) NOT NULL,

    table_concernee VARCHAR(150),

    identifiant_enregistrement UUID,

    ancienne_valeur JSONB,

    nouvelle_valeur JSONB,

    adresse_ip INET,

    user_agent TEXT,

    date_action TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE SET NULL,

    FOREIGN KEY (utilisateur_id)
        REFERENCES utilisateurs(id)
        ON DELETE SET NULL
);
