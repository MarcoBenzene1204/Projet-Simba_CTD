-- Trigger 1: Auto-update date_modification sur regies_avances
CREATE OR REPLACE FUNCTION update_date_modification() RETURNS TRIGGER AS $$
BEGIN
    NEW.date_modification = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_regies_modification
BEFORE UPDATE ON regies_avances
FOR EACH ROW EXECUTE FUNCTION update_date_modification();

-- Trigger 2: Vérif plafond RG-DEP-025 et calcul solde_disponible
CREATE OR REPLACE FUNCTION check_plafond_regie() RETURNS TRIGGER AS $$
DECLARE
    plafond NUMERIC;
BEGIN
    SELECT montant_plafond INTO plafond FROM regies_avances WHERE id = NEW.regie_avances_id;
    IF NEW.montant + (SELECT COALESCE(SUM(montant),0) FROM depenses_regies WHERE regie_avances_id = NEW.regie_avances_id AND id != NEW.id) > plafond THEN
        RAISE EXCEPTION 'RG-DEP-025: Depassement plafond regie % - Plafond: %', NEW.regie_avances_id, plafond;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_depenses_check_plafond
BEFORE INSERT OR UPDATE ON depenses_regies
FOR EACH ROW EXECUTE FUNCTION check_plafond_regie();

-- Trigger 3: Auto-update solde_disponible après INSERT/UPDATE/DELETE dépense
CREATE OR REPLACE FUNCTION maj_solde_regie() RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE regies_avances SET 
            montant_engages = (SELECT COALESCE(SUM(montant),0) FROM depenses_regies WHERE regie_avances_id = OLD.regie_avances_id),
            solde_disponible = montant_plafond - (SELECT COALESCE(SUM(montant),0) FROM depenses_regies WHERE regie_avances_id = OLD.regie_avances_id)
        WHERE id = OLD.regie_avances_id;
        RETURN OLD;
    ELSE
        UPDATE regies_avances SET 
            montant_engages = (SELECT COALESCE(SUM(montant),0) FROM depenses_regies WHERE regie_avances_id = NEW.regie_avances_id),
            solde_disponible = montant_plafond - (SELECT COALESCE(SUM(montant),0) FROM depenses_regies WHERE regie_avances_id = NEW.regie_avances_id)
        WHERE id = NEW.regie_avances_id;
        RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_maj_solde_after_depense
AFTER INSERT OR UPDATE OR DELETE ON depenses_regies
FOR EACH ROW EXECUTE FUNCTION maj_solde_regie();

-- Trigger 4: Alerte auto J+30 pour régularisation 470XX (RG-DEP-021)
CREATE OR REPLACE FUNCTION check_echeance_regularisation() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.date_echeance_regularisation < CURRENT_DATE AND NEW.etat NOT IN ('REGULIERISEE','CONTREPASSEE') THEN
        NEW.etat = 'DEPASSEMENT_DELAI';
        NEW.inscrit_registre_anomalies = TRUE;
        NEW.alerte_critique = TRUE;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_regularisation_echeance
BEFORE INSERT OR UPDATE ON regularisations_470xx
FOR EACH ROW EXECUTE FUNCTION check_echeance_regularisation();

-- V2__triggers_signature_cachet.sql
-- RG-DEP-013: Cachet DEPENSE VALIDEE obligatoire
-- RG-DEP-017: Double signature >= 100 000 FCFA

-- =======================================
-- 1. RG-DEP-013: Cachet DEPENSE VALIDEE
-- Un mandat ne peut pas être transmis au Receveur sans cachet CF
-- =======================================
CREATE OR REPLACE FUNCTION check_cachet_depense_validee() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.etat = 'TRANSMIS_RECEVEUR' THEN
        IF OLD.depense_validee_signal = FALSE OR OLD.controller_financier_visa_id IS NULL THEN
            RAISE EXCEPTION 'RG-DEP-013: Mandat % ne peut etre transmis au Receveur sans cachet DEPENSE VALIDEE du CF', OLD.numero_mandat;
        END IF;
        -- Auto-set date transmission
        NEW.date_transmission_receveur = NOW();
    END IF;
    
    IF NEW.etat = 'VISE_CF' THEN
        IF NEW.controller_financier_visa_id IS NULL THEN
            RAISE EXCEPTION 'RG-DEP-013: Visa CF obligatoire pour passer en VISE_CF';
        END IF;
        NEW.depense_validee_signal = TRUE;
        NEW.date_vali_cf = NOW();
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_mandat_cachet ON mandats;
CREATE TRIGGER trg_mandat_cachet
BEFORE UPDATE ON mandats
FOR EACH ROW EXECUTE FUNCTION check_cachet_depense_validee();

-- =======================================
-- 2. RG-DEP-017: Double signature >= 100 000 FCFA
-- Caisse < 100k : signature seule Receveur
-- Cheque/Virement >= 100k : Receveur + Cosignataire obligatoire
-- Investissement : toujours double signature
-- =======================================
CREATE OR REPLACE FUNCTION check_double_signature() RETURNS TRIGGER AS $$
DECLARE
    mandat_montant NUMERIC;
    mandat_mode VARCHAR;
    mandat_type VARCHAR;
BEGIN
    SELECT montant_nap, mode_paiement, type_mandat 
    INTO mandat_montant, mandat_mode, mandat_type
    FROM mandats WHERE id = NEW.mandat_id;

    -- Si paiement >= 100 000 ou type investissement / collectif
    IF mandat_montant >= 100000 THEN
        IF NEW.etat = 'EFFECTUE' THEN
            IF NEW.signature_receve_effectuee = FALSE THEN
                RAISE EXCEPTION 'RG-DEP-017: Signature Receveur obligatoire pour paiement >= 100 000 FCFA (Mandat %)', (SELECT numero_mandat FROM mandats WHERE id = NEW.mandat_id);
            END IF;
            IF NEW.cosignataider_id IS NULL OR NEW.signature_cosignatire_effectuee = FALSE THEN
                RAISE EXCEPTION 'RG-DEP-017: Double signature obligatoire (Receveur + Cosignataire) pour cheque/virement >= 100 000 FCFA. Mandat: % Montant: %', (SELECT numero_mandat FROM mandats WHERE id = NEW.mandat_id), mandat_montant;
            END IF;
        END IF;
    END IF;

    -- Si mode CHEQUE ou VIREMENT_BANCAIRE, cosignataire obligatoire même si < 100k en investissement
    IF mandat_mode IN ('CHEQUE','VIREMENT_BANCAIRE') AND NEW.etat = 'EFFECTUE' THEN
        IF mandat_type IN ('RETENUE_GARANTIE') OR mandat_montant >= 100000 THEN
            IF NEW.numero_cheque IS NULL AND NEW.ordre_virement_genere IS NULL THEN
                RAISE EXCEPTION 'RG-DEP-017: Numero cheque ou ordre virement obligatoire pour mode %', mandat_mode;
            END IF;
        END IF;
    END IF;

    -- Auto-set dates signature
    IF NEW.signature_receve_effectuee = TRUE AND OLD.signature_receve_effectuee = FALSE THEN
        NEW.date_signature_receveur = NOW();
    END IF;
    IF NEW.signature_cosignatire_effectuee = TRUE AND OLD.signature_cosignatire_effectuee = FALSE THEN
        IF NEW.cosignataider_id IS NULL THEN
            RAISE EXCEPTION 'RG-DEP-017: cosignataider_id doit etre defini avant signature cosignataire';
        END IF;
        NEW.date_signature_cosignataire = NOW();
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_paiement_double_signature ON paiements;
CREATE TRIGGER trg_paiement_double_signature
BEFORE UPDATE ON paiements
FOR EACH ROW EXECUTE FUNCTION check_double_signature();

-- =======================================
-- 3. RG-DEP-016: Mode paiement auto selon montant (BONUS)
-- =======================================
CREATE OR REPLACE FUNCTION set_mode_paiement_auto() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.mode_paiement IS NULL THEN
        IF NEW.montant_nap < 100000 AND NEW.type_mandat = 'INDIVIDUEL' THEN
            NEW.mode_paiement = 'CAISSE';
        ELSE
            NEW.mode_paiement = 'CHEQUE';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_mandat_mode_paiement ON mandats;
CREATE TRIGGER trg_mandat_mode_paiement
BEFORE INSERT ON mandats
FOR EACH ROW EXECUTE FUNCTION set_mode_paiement_auto();

-- =======================================
-- 4. Vue pour alertes trésorerie Receveur
-- =======================================
CREATE OR REPLACE VIEW v_alertes_paiements AS
SELECT 
    p.id,
    m.numero_mandat,
    m.montant_nap,
    m.mode_paiement,
    p.etat,
    p.receve_id,
    CASE 
        WHEN m.montant_nap >= 100000 AND p.signature_cosignatire_effectuee = FALSE THEN 'ATTENTE_COSIGNATURE'
        WHEN m.etat = 'TRANSMIS_RECEVEUR' AND p.cachet_vu_bon_a_payer = FALSE THEN 'ATTENTE_VU_BON_A_PAYER'
        ELSE 'OK'
    END as alerte
FROM paiements p
JOIN mandats m ON p.mandat_id = m.id
WHERE p.etat NOT IN ('EFFECTUE','ECHEC');