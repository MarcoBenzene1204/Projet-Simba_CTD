CREATE TABLE regies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    exercice_id UUID NOT NULL,

    code VARCHAR(50) NOT NULL,

    libelle VARCHAR(255) NOT NULL,

    type_regie type_regie NOT NULL DEFAULT 'AVANCES',

    plafond NUMERIC(19,2) NOT NULL,

    solde NUMERIC(19,2) NOT NULL DEFAULT 0,

    nature_depenses JSONB NOT NULL DEFAULT '[]'::jsonb,

    deliberation_reference VARCHAR(150),

    date_creation DATE NOT NULL,

    statut statut_regie NOT NULL DEFAULT 'ACTIVE',

    regisseur_id UUID NOT NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (exercice_id)
        REFERENCES exercices_budgetaires(id),

    FOREIGN KEY (regisseur_id)
        REFERENCES utilisateurs(id),

    UNIQUE (collectivite_id, code)
);


CREATE TABLE depenses_regie (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    regie_id UUID NOT NULL,

    reference VARCHAR(100) NOT NULL,

    objet TEXT NOT NULL,

    montant NUMERIC(19,2) NOT NULL,

    date_depense DATE NOT NULL,

    justificatif_url TEXT,

    apuree BOOLEAN NOT NULL DEFAULT FALSE,

    ordonnee BOOLEAN NOT NULL DEFAULT FALSE,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (regie_id)
        REFERENCES regies(id)
        ON DELETE CASCADE,

    UNIQUE (collectivite_id, reference)
);
