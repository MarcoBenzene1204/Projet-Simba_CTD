CREATE TABLE paiements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    mandat_id UUID NOT NULL,

    numero VARCHAR(100) NOT NULL,

    mode_reglement mode_reglement NOT NULL,

    montant_ttc NUMERIC(19,2) NOT NULL,

    montant_retenues NUMERIC(19,2) NOT NULL DEFAULT 0,

    montant_net_paye NUMERIC(19,2) NOT NULL,

    date_programmee DATE,

    date_execution DATE,

    statut statut_paiement NOT NULL DEFAULT 'PROGRAMME',

    reference_bancaire VARCHAR(150),

    reference_cheque VARCHAR(150),

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (mandat_id)
        REFERENCES mandats(id),

    UNIQUE (collectivite_id, numero)
);
