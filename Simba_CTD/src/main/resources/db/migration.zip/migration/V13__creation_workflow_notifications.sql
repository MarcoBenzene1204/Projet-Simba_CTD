CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    utilisateur_id UUID NOT NULL,

    titre VARCHAR(255) NOT NULL,

    message TEXT NOT NULL,

    niveau niveau_notification NOT NULL DEFAULT 'INFO',

    lu BOOLEAN NOT NULL DEFAULT FALSE,

    date_lecture TIMESTAMPTZ,

    lien VARCHAR(500),

    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (utilisateur_id)
        REFERENCES utilisateurs(id)
        ON DELETE CASCADE
);
