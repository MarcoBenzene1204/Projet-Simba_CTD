CREATE TABLE engagements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    exercice_id UUID NOT NULL,

    ligne_budgetaire_id UUID NOT NULL,

    tiers_id UUID,

    document_preparatoire_id UUID,

    numero VARCHAR(100) NOT NULL,

    type_engagement type_engagement NOT NULL,

    objet TEXT NOT NULL,

    montant_ht NUMERIC(19,2) NOT NULL DEFAULT 0,
    montant_taxes NUMERIC(19,2) NOT NULL DEFAULT 0,
    montant_ttc NUMERIC(19,2) NOT NULL DEFAULT 0,

    montant_engage NUMERIC(19,2) NOT NULL DEFAULT 0,

    statut statut_engagement NOT NULL DEFAULT 'BROUILLON',

    date_engagement DATE NOT NULL,

    soumis_cf_at TIMESTAMPTZ,
    vise_cf_at TIMESTAMPTZ,

    utilisateur_createur_id UUID,

    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (exercice_id)
        REFERENCES exercices_budgetaires(id),

    FOREIGN KEY (ligne_budgetaire_id)
        REFERENCES lignes_budgetaires(id),

    FOREIGN KEY (tiers_id)
        REFERENCES tiers(id),

    FOREIGN KEY (document_preparatoire_id)
        REFERENCES documents_preparatoires(id),

    FOREIGN KEY (utilisateur_createur_id)
        REFERENCES utilisateurs(id),

    UNIQUE (collectivite_id, numero)
);


CREATE TABLE avis_controle_financier (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    engagement_id UUID NOT NULL,

    controleur_id UUID NOT NULL,

    type_avis type_avis_controle NOT NULL,

    observations TEXT,

    reserves TEXT,

    tiers VARCHAR(100),

    date_reception TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    date_decision TIMESTAMPTZ,

    reference_document TEXT,

    autorisation_minfi TEXT,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (engagement_id)
        REFERENCES engagements(id)
        ON DELETE CASCADE,

    FOREIGN KEY (controleur_id)
        REFERENCES utilisateurs(id)
);
