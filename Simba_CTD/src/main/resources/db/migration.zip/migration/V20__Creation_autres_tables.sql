-- 1. REGIES_AVANCES (parent)
CREATE TABLE regies_avances (
    id UUID PRIMARY KEY,
    numero_regie VARCHAR(255) NOT NULL,
    date_creation DATE NOT NULL,
    periodicite VARCHAR(255) NOT NULL CHECK (periodicite IN ('TRIMESTRIELLE','SEMESTRIELLE')),
    regisseur_id UUID NOT NULL,
    numero_deliberation VARCHAR(255) NOT NULL,
    date_deliberation DATE NOT NULL,
    date_approval_deliberation DATE NOT NULL,
    montant_plafond NUMERIC(38,2) NOT NULL,
    montant_total NUMERIC(38,2) NOT NULL,
    montant_engages NUMERIC(38,2) NOT NULL,
    montant_autorises NUMERIC(38,2) NOT NULL,
    montant_ordonnances NUMERIC(38,2) NOT NULL,
    montant_paye NUMERIC(38,2) NOT NULL,
    solde_disponible NUMERIC(38,2) NOT NULL,
    natures_autorisees VARCHAR(255) NOT NULL,
    etat VARCHAR(255) NOT NULL CHECK (etat IN ('ACTIVE','EN_APUREMENT','SUSPENDUE','CLOTUREEXERCICE','FERMEE')),
    montant_dernier_reconstitution NUMERIC(38,2),
    date_dernier_reconstitution DATE,
    regie_cloture_exercice BOOLEAN,
    date_cloture_exercice DATE,
    solde_reversement NUMERIC(38,2),
    date_reversement_effectuee TIMESTAMP,
    date_modification TIMESTAMP NOT NULL
);

-- 3. APUREMENTS_REGIES
CREATE TABLE apurements_regies (
    id UUID PRIMARY KEY,
    regieavances_id UUID NOT NULL REFERENCES regies_avances(id),
    date_periode DATE NOT NULL,
    montant_soumis NUMERIC(38,2) NOT NULL,
    controller_financier_visa_id VARCHAR(255),
    date_visa_cf TIMESTAMP,
    etat VARCHAR(255) NOT NULL CHECK (etat IN ('EN_COURS','VISEE_CF','ORDONNANCEE','PAYEE'))
);

-- 4. DEPENSES_REGIES
CREATE TABLE depenses_regies (
    id UUID PRIMARY KEY,
    regie_avances_id UUID NOT NULL REFERENCES regies_avances(id),
    nature VARCHAR(100) NOT NULL,
    montant NUMERIC(15,2) NOT NULL,
    date_depense DATE NOT NULL,
    description VARCHAR(500),
    url_justificatifs VARCHAR(255),
    etat VARCHAR(30) NOT NULL CHECK (etat IN ('SAISIE','VALIDEE','AUTORISEE','ORDONNANCEE','PAYEE'))
);

-- 5. LIQUIDATIONS
CREATE TABLE liquidations (
    id UUID PRIMARY KEY,
    engagement_id UUID NOT NULL REFERENCES engagements(id),
    type_facture VARCHAR(255) NOT NULL CHECK (type_facture IN ('COMPLETE','PARTIELLE','PRO_FORMA','AVOIR','RECTIFICATIVE','REGULARISATION')),
    numero_facture VARCHAR(255) NOT NULL,
    date_facture DATE NOT NULL,
    montant_ht_liquide NUMERIC(38,2) NOT NULL,
    taux_tva NUMERIC(38,2) NOT NULL,
    montant_tva_liquide NUMERIC(38,2) NOT NULL,
    montant_ttc_liquide NUMERIC(38,2) NOT NULL,
    taux_impot_retenue NUMERIC(38,2) NOT NULL,
    montant_impot_retenue NUMERIC(38,2) NOT NULL,
    montant_nap NUMERIC(38,2) NOT NULL,
    detail_prestations VARCHAR(255),
    service_fait_ateste BOOLEAN NOT NULL,
    agent_service_fait_id UUID,
    date_atestation_service_fait TIMESTAMP,
    attestation_fiscale_presente BOOLEAN NOT NULL,
    url_attestation_fiscale VARCHAR(255),
    url_facture VARCHAR(255),
    etat VARCHAR(255) NOT NULL CHECK (etat IN ('BROUILLON','SOUMISE_CF','VALIDEE_CF','REJETEE','PRETE_ORDONNANCEMENT')),
    date_creation TIMESTAMP NOT NULL,
    date_validation TIMESTAMP,
    ordonnator_id UUID,
    controller_financier_validation_id UUID,
    numero_liquidation_originale VARCHAR(255),
    ecart_regularise NUMERIC(38,2)
);

-- 6. MANDATS
CREATE TABLE mandats (
    id UUID PRIMARY KEY,
    numero_mandat VARCHAR(255) NOT NULL UNIQUE,
    date_mandat TIMESTAMP NOT NULL,
    type_mandat VARCHAR(255) NOT NULL CHECK (type_mandat IN ('INDIVIDUEL','COLLECTIF','REGULARISATION','RETENUE_GARANTIE','REGLEMENT_OFFICE')),
    engagement_id UUID REFERENCES engagements(id),
    periode_versement VARCHAR(255),
    montant_ttc_mandate NUMERIC(38,2) NOT NULL,
    montant_retenu_source NUMERIC(38,2),
    montant_nap NUMERIC(38,2) NOT NULL,
    ordonnator_id UUID NOT NULL,
    controller_financier_visa_id UUID,
    receve_id UUID,
    cosignataider_id UUID,
    etat VARCHAR(255) NOT NULL CHECK (etat IN ('BROUILLON','SOUMIS_CF','VISE_CF','TRANSMIS_RECEVEUR','REJET_CF')),
    depense_validee_signal BOOLEAN NOT NULL,
    date_vali_cf TIMESTAMP,
    mode_paiement VARCHAR(255) CHECK (mode_paiement IN ('CAISSE','CHEQUE','VIREMENT_BANCAIRE')),
    date_creation TIMESTAMP NOT NULL,
    date_soumission_cf TIMESTAMP,
    date_transmission_receveur TIMESTAMP,
    url_liasse_documents VARCHAR(255),
    url_bordereau_mandats VARCHAR(255),
    etat_paiement VARCHAR(255) NOT NULL CHECK (etat_paiement IN ('EN_ATTENTE','PROGRAMME','EN_COURS','EFFECTUE','ECHEC')),
    date_paiement TIMESTAMP,
    numero_check_paiement VARCHAR(255)
);

-- 7. LIGNE_MANDAT
CREATE TABLE ligne_mandat (
    id UUID PRIMARY KEY,
    mandat_id UUID NOT NULL REFERENCES mandats(id),
    liquidation_id UUID NOT NULL REFERENCES liquidations(id),
    numero_ligne INTEGER NOT NULL,
    montant_ttc NUMERIC(38,2) NOT NULL,
    montant_nap NUMERIC(38,2) NOT NULL,
    tiers_id VARCHAR(255) NOT NULL,
    tiers_beneficiaire VARCHAR(255) NOT NULL,
    compte_comptable_tiers VARCHAR(255)
);

-- 8. PAIEMENTS
CREATE TABLE paiements (
    id UUID PRIMARY KEY,
    mandat_id UUID NOT NULL UNIQUE REFERENCES mandats(id),
    receve_id UUID NOT NULL,
    cosignataider_id UUID,
    date_reception_mandat TIMESTAMP NOT NULL,
    date_programmation_paiement TIMESTAMP,
    date_paiement TIMESTAMP,
    validit_creance_verifiee BOOLEAN NOT NULL,
    prescription_verifiee BOOLEAN NOT NULL,
    oppositions_verifiees BOOLEAN NOT NULL,
    redevabilite_verifiee BOOLEAN NOT NULL,
    cachet_vu_bon_a_payer BOOLEAN NOT NULL,
    date_apposition_cachet TIMESTAMP,
    montant_ttc_paye NUMERIC(38,2) NOT NULL,
    montant_retenu_source NUMERIC(38,2) NOT NULL,
    montant_nap_verse NUMERIC(38,2) NOT NULL,
    disponibilites_caisse NUMERIC(38,2),
    disponibilites_banque NUMERIC(38,2),
    disponibilites_suffisantes BOOLEAN,
    justification_differement VARCHAR(255),
    date_signature_receveur TIMESTAMP,
    date_signature_cosignataire TIMESTAMP,
    signature_receve_effectuee BOOLEAN NOT NULL,
    signature_cosignatire_effectuee BOOLEAN,
    ordre_virement_genere VARCHAR(255),
    numero_cheque VARCHAR(255),
    etat VARCHAR(255) NOT NULL CHECK (etat IN ('EN_ATTENTE','PROGRAMME','VU_BON_A_PAYER','EN_COURS','EFFECTUE','ECHEC','DIFFERE')),
    date_creation TIMESTAMP NOT NULL,
    motif_echec VARCHAR(255)
);

-- 9. REGULARISATIONS_470XX
-- 9. REGULARISATIONS_470XX
CREATE TABLE regularisations_470xx (
    id UUID PRIMARY KEY,
    date_detection TIMESTAMP NOT NULL,
    reference_paiement_detecte VARCHAR(255) NOT NULL,
    engagement_id UUID REFERENCES engagements(id),
    montant_detecte NUMERIC(38,2) NOT NULL,
    montant_imputation NUMERIC(38,2) NOT NULL,
    nature_depense VARCHAR(255) NOT NULL,
    description VARCHAR(255),
    receve_id UUID NOT NULL,
    ordonnator_id UUID NOT NULL,
    controller_financier_visa_id UUID,
    etat VARCHAR(255) NOT NULL CHECK (etat IN (
        'DETECTEE',
        'NOTIFIEE',
        'ENGAGEMENT_CREE',
        'SOUMIS_CF',
        'VISE_CF',
        'REJET_CF',
        'LIQUIDEE',
        'MANDATEE',
        'CONTREPASSEE',
        'REGULIERISEE',
        'DEPASSEMENT_DELAI'
    )),
    comptabilisee_compte470xx BOOLEAN NOT NULL,
    numero_ecriture_comptable470xx VARCHAR(255),
    date_notification_ordonnateur TIMESTAMP,
    ordonnator_notifie BOOLEAN NOT NULL,
    date_creation_engagement TIMESTAMP,
    date_visa_cf TIMESTAMP,
    delai_visa_cf INTEGER,
    mandat_regularisation_id UUID REFERENCES mandats(id),
    contrepassation470xx_autoeffectuee BOOLEAN NOT NULL,
    numero_ecriture_contrepassation VARCHAR(255),
    date_echeance_regularisation DATE NOT NULL,
    alerte_j15_declenchee BOOLEAN,
    alerte_j25_declenchee BOOLEAN,
    alerte_critique BOOLEAN,
    date_creation TIMESTAMP NOT NULL,
    motif_rejet_cf VARCHAR(255),
    inscrit_registre_anomalies BOOLEAN,
    notification_tutelle_envoyee BOOLEAN
);