ALTER TABLE utilisateurs
ADD COLUMN IF NOT EXISTS collectivite_id UUID;

DO $$
BEGIN
	IF NOT EXISTS (
		SELECT 1
		FROM pg_constraint
		WHERE conname = 'fk_utilisateur_collectivite'
	) THEN
		ALTER TABLE utilisateurs
		ADD CONSTRAINT fk_utilisateur_collectivite
		FOREIGN KEY (collectivite_id)
		REFERENCES collectivites(id)
		ON DELETE RESTRICT;
	END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_utilisateurs_collectivite
ON utilisateurs(collectivite_id);
