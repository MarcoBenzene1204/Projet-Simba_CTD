CREATE TABLE liquidations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    collectivite_id UUID NOT NULL,

    engagement_id UUID NOT NULL,

    numero VARCHAR(100) NOT NULL,

    type_facture type_facture NOT NULL,

    numero_facture VARCHAR(100) NOT NULL,

    date_facture DATE NOT NULL,

    montant_ht NUMERIC(19,2) NOT NULL,
    montant_taxes NUMERIC(19,2) NOT NULL DEFAULT 0,
    montant_ttc NUMERIC(19,2) NOT NULL,
    montant_nap NUMERIC(19,2),

    statut statut_liquidation NOT NULL DEFAULT 'BROUILLON',

    service_fait_at TIMESTAMPTZ,

    conformite_fiscale BOOLEAN NOT NULL DEFAULT FALSE,

    observations TEXT,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (collectivite_id)
        REFERENCES collectivites(id)
        ON DELETE CASCADE,

    FOREIGN KEY (engagement_id)
        REFERENCES engagements(id),

    UNIQUE (collectivite_id, numero),

    UNIQUE (collectivite_id, numero_facture)
);
