package com.marco.Simba_CTD.security;

public enum ApplicationRole {

    ADMINISTRATEUR,
    CONTROLEUR_FINANCIER,
    ORDONNATEUR,
    REGISSEUR,
    COSIGNATAIRE,
    CHEF_SERVICE,
    RECEVEUR
}
