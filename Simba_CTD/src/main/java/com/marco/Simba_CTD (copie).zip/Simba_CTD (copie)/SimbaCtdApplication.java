package com.marco.Simba_CTD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimbaCtdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimbaCtdApplication.class, args);
	}

}
