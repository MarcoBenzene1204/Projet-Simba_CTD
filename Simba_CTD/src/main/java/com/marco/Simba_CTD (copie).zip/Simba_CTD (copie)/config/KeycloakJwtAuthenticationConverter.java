package com.marco.Simba_CTD.config;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class KeycloakJwtAuthenticationConverter
        implements Converter<Jwt, AbstractAuthenticationToken> {

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {

        Collection<GrantedAuthority> authorities =
                extractRealmRoles(jwt);

        return new JwtAuthenticationToken(
                jwt,
                authorities,
                getPrincipalName(jwt)
        );
    }

    private String getPrincipalName(Jwt jwt) {

        String username = jwt.getClaimAsString(
                "preferred_username"
        );

        return username != null
                ? username
                : jwt.getSubject();
    }

    @SuppressWarnings("unchecked")
    private Collection<GrantedAuthority> extractRealmRoles(
            Jwt jwt
    ) {

        Map<String, Object> realmAccess =
                jwt.getClaim("realm_access");

        if (realmAccess == null) {
            return List.of();
        }

        Object rolesObject =
                realmAccess.get("roles");

        if (!(rolesObject instanceof List<?> roles)) {
            return List.of();
        }

        return roles.stream()
                .filter(String.class::isInstance)
                .map(String.class::cast)
                .map(role ->
                        new SimpleGrantedAuthority(
                                "ROLE_" + role.toUpperCase()
                        )
                )
                .collect(Collectors.toSet());
    }
}
